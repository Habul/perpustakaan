<?php return array (
  'admin.user' => 'App\\Http\\Livewire\\Admin\\User',
  'peminjam.buku' => 'App\\Http\\Livewire\\Peminjam\\Buku',
  'peminjam.kategori' => 'App\\Http\\Livewire\\Peminjam\\Kategori',
  'peminjam.keranjang' => 'App\\Http\\Livewire\\Peminjam\\Keranjang',
  'petugas.buku' => 'App\\Http\\Livewire\\Petugas\\Buku',
  'petugas.chart' => 'App\\Http\\Livewire\\Petugas\\Chart',
  'petugas.chart-script' => 'App\\Http\\Livewire\\Petugas\\ChartScript',
  'petugas.kategori' => 'App\\Http\\Livewire\\Petugas\\Kategori',
  'petugas.penerbit' => 'App\\Http\\Livewire\\Petugas\\Penerbit',
  'petugas.rak' => 'App\\Http\\Livewire\\Petugas\\Rak',
  'petugas.transaksi' => 'App\\Http\\Livewire\\Petugas\\Transaksi',
);