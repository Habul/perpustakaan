<footer class="main-footer">
    <strong>Copyright &copy; {{ date('Y') }} <a href="https://github.com/Habul" rel="noopener" target="_blank">
            Habul</a></strong> . All rights
    reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Tugas Akhir</b> - Aplikasi Manajemen Perpustakaan
    </div>
</footer>
