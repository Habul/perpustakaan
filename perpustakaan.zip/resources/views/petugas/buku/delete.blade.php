 @if ($delete)
     <div class="modal fade show" id="modal-default" style="display: block; padding-right: 17px;">
         <div class="modal-dialog modal-dialog-centered">
             <div class="modal-content bg-light color-palette">
                 <div class="modal-header">
                     <h4 class="modal-title">Hapus Buku</h4>
                     <span wire:click="format" type="button" class="close" data-dismiss="modal" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                     </span>
                 </div>
                 <div class="modal-body">
                     <span>Anda yakin ingin mengahapus buku {{ $judul }} ?</span>
                 </div>
                 <div class="modal-footer justify-content-between">
                     <span wire:click="format" type="button" class="btn btn-default" data-dismiss="modal">
                         <i class="fas fa-times-circle"></i> Batal</span>
                     <span type="button" wire:click="destroy({{ $buku_id }})" class="btn btn-danger">
                         <i class="fa fa-trash"></i> Hapus</span>
                 </div>
             </div>
         </div>
     </div>
 @endif
