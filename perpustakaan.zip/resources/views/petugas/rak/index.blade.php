@extends('admin-lte/app')
@section('title', 'Rak')
@section('active-rak', 'active')
@section('active-data-master', 'active')
@section('menu-open-data-master', 'menu-open')

@section('content')
    <livewire:petugas.rak></livewire:petugas.rak>
@endsection
