@extends('admin-lte/app')
@section('title', 'User')
@section('active-user', 'active')

@section('content')
    <livewire:admin.user></livewire:admin.user>
@endsection
