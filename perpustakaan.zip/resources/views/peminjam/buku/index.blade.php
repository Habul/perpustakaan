@extends('layouts/app')

@section('content')
    <livewire:peminjam.buku></livewire:peminjam.buku>
@endsection
